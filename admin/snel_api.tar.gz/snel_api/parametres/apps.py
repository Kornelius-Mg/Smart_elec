from django.apps import AppConfig


class ParametresConfig(AppConfig):
    name = 'parametres'
