

def get_infos():
    return True