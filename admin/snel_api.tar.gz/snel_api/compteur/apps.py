from django.apps import AppConfig


class CompteurConfig(AppConfig):
    name = 'compteur'
