from django.apps import AppConfig


class TransfosConfig(AppConfig):
    name = 'transfos'
