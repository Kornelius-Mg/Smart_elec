from django.apps import AppConfig


class TransfertsConfig(AppConfig):
    name = 'transferts'
