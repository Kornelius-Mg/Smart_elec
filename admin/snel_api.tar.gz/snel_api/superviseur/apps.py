from django.apps import AppConfig


class SuperviseurConfig(AppConfig):
    name = 'superviseur'
